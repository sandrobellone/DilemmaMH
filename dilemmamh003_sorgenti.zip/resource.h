#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_DIALOG1                             100
#define IDC_BT_STOP                             40000
#define IDC_BT_AVVIA                            40001
#define IDC_BT_ESCI                             40002
#define IDC_EC_NS                               40003
#define IDC_EC_ITE                              40004
#define IDC_EC_NSS                              40005
#define IDC_EC_NITE                             40006
#define IDC_EC_NSE                              40007
#define IDC_RB_RAND                             40008
#define IDC_RB_SEMPRE                           40009
#define IDC_RB_MAI                              40010
#define IDC_RB_ALT                              40011
#define IDC_BT_RST                              40012
#define IDC_BT_ABOUT                            40013
